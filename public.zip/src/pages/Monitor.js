import React from 'react'
import Header from '../components/Header'

const Monitor = () => {
  return (
    <div className="bg-blue-main w-100">
      <Header />
      Monitor Settings
    </div>
  );
}

export default Monitor
